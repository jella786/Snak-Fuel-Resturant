import {
  User,
  Product,
  Category,
  Offer,
  Coupon,
  Order,
  SupportTicket,
  Review,
  DeliveryRider,
  ChatMessage,
  NotificationItem,
  RestaurantSettings,
} from '../types';

const BASE_URL = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('snackfuel_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }
  return data;
}

export const api = {
  // Auth
  register: (payload: { name: string; email: string; password: string; phone?: string }) =>
    request<{ user: User; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (payload: { email: string; password: string }) =>
    request<{ user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  quickSwitchRole: (role: string) =>
    request<{ user: User; token: string }>('/auth/quick-switch', {
      method: 'POST',
      body: JSON.stringify({ role }),
    }),

  getMe: () => request<User>('/auth/me'),

  updateProfile: (payload: Partial<User>) =>
    request<User>('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  // Settings
  getSettings: () => request<RestaurantSettings>('/settings'),
  updateSettings: (payload: Partial<RestaurantSettings>) =>
    request<RestaurantSettings>('/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  // Categories
  getCategories: () => request<Category[]>('/categories'),
  createCategory: (payload: Partial<Category>) =>
    request<Category>('/categories', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateCategory: (id: string, payload: Partial<Category>) =>
    request<Category>(`/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteCategory: (id: string) =>
    request<{ success: boolean }>(`/categories/${id}`, { method: 'DELETE' }),

  // Products
  getProducts: () => request<Product[]>('/products'),
  getProduct: (id: string) => request<Product>(`/products/${id}`),
  createProduct: (payload: Partial<Product>) =>
    request<Product>('/products', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateProduct: (id: string, payload: Partial<Product>) =>
    request<Product>(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteProduct: (id: string) =>
    request<{ success: boolean }>(`/products/${id}`, { method: 'DELETE' }),

  // Offers
  getOffers: () => request<Offer[]>('/offers'),
  createOffer: (payload: Partial<Offer>) =>
    request<Offer>('/offers', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateOffer: (id: string, payload: Partial<Offer>) =>
    request<Offer>(`/offers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteOffer: (id: string) =>
    request<{ success: boolean }>(`/offers/${id}`, { method: 'DELETE' }),

  // Coupons
  getCoupons: () => request<Coupon[]>('/coupons'),
  validateCoupon: (code: string, orderAmount: number) =>
    request<{ valid: boolean; code: string; discount: number; coupon: Coupon }>('/coupons/validate', {
      method: 'POST',
      body: JSON.stringify({ code, orderAmount }),
    }),
  createCoupon: (payload: Partial<Coupon>) =>
    request<Coupon>('/coupons', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateCoupon: (id: string, payload: Partial<Coupon>) =>
    request<Coupon>(`/coupons/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteCoupon: (id: string) =>
    request<{ success: boolean }>(`/coupons/${id}`, { method: 'DELETE' }),

  // Orders
  getOrders: () => request<Order[]>('/orders'),
  getOrder: (id: string) => request<Order>(`/orders/${id}`),
  createOrder: (payload: any) =>
    request<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateOrderStatus: (id: string, status: string, cancellationReason?: string) =>
    request<Order>(`/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, cancellationReason }),
    }),
  assignRider: (orderId: string, riderId: string) =>
    request<Order>(`/orders/${orderId}/assign-rider`, {
      method: 'PUT',
      body: JSON.stringify({ riderId }),
    }),

  // Rider portal
  getRiderOrders: () => request<Order[]>('/rider/orders'),
  updateRiderOrderStatus: (id: string, status: string) =>
    request<Order>(`/rider/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),

  // Messages
  getOrderMessages: (orderId: string) => request<ChatMessage[]>(`/orders/${orderId}/messages`),
  sendOrderMessage: (orderId: string, payload: { message: string; senderRole?: string; senderName?: string }) =>
    request<ChatMessage>(`/orders/${orderId}/messages`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Support
  getSupportTickets: () => request<SupportTicket[]>('/support/tickets'),
  getSupportTicket: (id: string) => request<SupportTicket>(`/support/tickets/${id}`),
  createSupportTicket: (payload: { subject: string; category: string; message: string; orderId?: string }) =>
    request<SupportTicket>('/support/tickets', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  replySupportTicket: (id: string, text: string) =>
    request<SupportTicket>(`/support/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    }),
  updateTicketStatus: (id: string, status: string) =>
    request<SupportTicket>(`/support/tickets/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),

  // Reviews
  getReviews: () => request<Review[]>('/reviews'),
  submitReview: (payload: {
    orderId?: string;
    productId?: string;
    rating: number;
    foodRating?: number;
    deliveryRating?: number;
    comment: string;
  }) =>
    request<Review>('/reviews', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Favorites
  getFavorites: () => request<{ ids: string[]; products: Product[] }>('/favorites'),
  toggleFavorite: (productId: string) =>
    request<{ ids: string[]; isFavorite: boolean }>('/favorites/toggle', {
      method: 'POST',
      body: JSON.stringify({ productId }),
    }),

  // Admin users & riders
  getAdminUsers: () => request<User[]>('/admin/users'),
  toggleUserActive: (id: string) =>
    request<User>(`/admin/users/${id}/toggle`, { method: 'PUT' }),
  getAdminRiders: () => request<DeliveryRider[]>('/admin/riders'),
  createRider: (payload: Partial<DeliveryRider>) =>
    request<DeliveryRider>('/admin/riders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateRider: (id: string, payload: Partial<DeliveryRider>) =>
    request<DeliveryRider>(`/admin/riders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteRider: (id: string) =>
    request<{ success: boolean }>(`/admin/riders/${id}`, { method: 'DELETE' }),

  getAdminStats: () =>
    request<{
      metrics: {
        totalOrders: number;
        pendingOrders: number;
        activeOrders: number;
        completedOrders: number;
        cancelledOrders: number;
        totalRevenue: number;
        totalCustomers: number;
        activeRiders: number;
        totalProducts: number;
      };
      dailySales: Array<{ day: string; sales: number; orders: number }>;
    }>('/admin/stats'),

  // Notifications
  getNotifications: () => request<NotificationItem[]>('/notifications'),
  markNotificationRead: (id: string) =>
    request<{ success: boolean }>(`/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () =>
    request<{ success: boolean }>('/notifications/read-all', { method: 'PUT' }),

  // Upload image
  uploadImage: (dataUrl: string) =>
    request<{ url: string; success: boolean }>('/upload', {
      method: 'POST',
      body: JSON.stringify({ dataUrl }),
    }),
};
